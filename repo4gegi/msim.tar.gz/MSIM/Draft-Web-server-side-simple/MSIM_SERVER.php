<?
include ('/var/www/html/a2billing/customer/lib/customer.defines.php');
ini_set('timeout', 900);
ini_set('SessionTimeout', 30);
ini_set('display_errors', 1);
ini_set('error_reporting', Off);


class USSDXMLSMS {

private $cphone=array();
private $cclient=array();
private  $ctitle=array();
private $cattempt=array();
private $cemail=array();
private $x1;
private $y2;
public  $notel;
public  $notitle;
public $split;
public $msisdn;

function init()

{
$this->notel=true;
$this->notitle=true;

$spliter =  explode('#' , $this->split); 

foreach ($spliter as $chunk)
 {
  $devid0 = explode(';', $chunk);
  if (isset($devid0[0]))
  {
  switch($devid0[0]) {
  case 'GPS':
          $this->fcoordinates($devid0);
          break;
  case 'PN':
          $this->fphone($devid0);
          break;       
  case 'CL':
          $this->fclient($devid0); 
          break;
  case 'MSG':
         $this->ftitle($devid0);
          break;
  case 'ATN';
          $this->fattempt($devid0);
          break; 
  case 'EM';
          $this->femail($devid0);

                    }

   }
  }
 }

    
 private function fcoordinates($arr)
   {
   if ( substr($arr[1], 0, 7) === '$GPRMC,' ) {
	$arr[1] = substr($arr[1], 7);
   }
  
   $spliter=(preg_split('/,/',$arr[1]));
   //var_dump($spliter);
   if ($spliter[1] == 'A')
   {
   $this->x1 = $this->degree2decimal("$spliter[2].$spliter[3]");
   //var_dump($this->x1); 
   $this->y1 = $this->degree2decimal("$spliter[4].$spliter[5]");
   //var_dump($this->y1);
   }
   else
     {
  //   var_dump($spliter[1]);
  //   var_dump($spliter[2]);
     $this->x1 = $spliter[0];
     $this->y1 = $spliter[1];
     }
}
 private function fphone($arr)
   {
    $this->cphone=array_splice(array_map("trim",$arr),1);
    $this->cphone=explode(',' , $this->cphone[0]);
/*  telephone format 
    $arrcount = count($this->cphone)-1;
    for($i=0;$i<=$arrcount;$i++)
    {
     
     $pmres = preg_match('|[+][0-9]{7,}+$|', $this->cphone[$i], $matches);
    if (empty($matches)) 
    {
    unset($this->cphone[$i]); 
    
    }
    }
    if (empty($this->cphone) || ($this->cphone)=="")
        $this->notel = true;
       else 
       $this->notel = false;
*/
     if (empty($this->cphone) || ($this->cphone[0])=="")
     $this->notel=true;
     else
     $this->notel=false;
    }
 private function fclient($arr)
   {
  $this->cclient=array_splice(array_map("trim",$arr),1);   
   }

 private function ftitle($arr)  
   {
  $this->ctitle=$arr[1]; 
  if(empty($this->ctitle)) 
  $this->notitle = true;
  else
  $this->notitle = false;
   }

 private  function fattempt($arr)  
   {
 $this->cattempt=$arr[1];  
   }

 private  function femail($arr)
   {
  $this->cemail=array_splice(array_map("trim",$arr),1);
  $this->cemail=explode(',' , $this->cemail[0]);
   }
  

function degree2decimal($deg_coord){
   //reference http://www.directionsmag.com/site/latlong-converter
   //GPS/NMEA fixes are in Degree Minutes.m format
   //for Google maps we need to convert them to decimal degrees
   //sample format of GPS 4533.35 is 45 degrees and 33.35 minutes
   //formula is as follows//Degrees=Degrees 
   //.d = M.m/60//Decimal Degrees=Degrees+.d
   $degree0 = $deg_coord;
   $degree1 =  explode(".",$degree0);
   $memb_n = count($degree1);
   if ($memb_n == 3)
   {
   $degree2=(int)($degree1[0]/100); //simple way
   $minutes= $degree1[0]-($degree2*100);
   $dotdegree=$minutes/60;
   $decimal=(float)($degree2+$dotdegree);
   $degree3 = (int)($degree1[1]/100);
   $mseconds1 =  $degree1[1]-($degree3*100);
   $mseconds1dec = $mseconds1/216000;
   $degree3dec =  $degree3/3600 + $mseconds1dec;
   $decimal = $decimal + $degree3dec;
   //South latitudes and West longitudes need to return a negative result
   if (($degree1[3]=="S") or ($degree1[3]=="W"))
   {
   $decimal=$decimal*(-1);
   }
   $decimal=number_format($decimal,8,'.',''); //truncate decimal to 8 places
   return $decimal;
}

else {
      if ($memb_n == 4)
       {
          $degree2=(int)($degree1[0]/100); //simple way
   $minutes= $degree1[0]-($degree2*100);
   $dotdegree=$minutes/60;
   $decimal=(float)($degree2+$dotdegree);
   $degree3 = $degree1[1]/3600;
   //$direction=substr($deg_coord,-1);
   $degree4=substr($degree1[2],0,2)/216000;
   $decimal =  $decimal + $degree3 + $degree4;
   //South latitudes and West longitudes need to return a negative result
   if (($degree1[2]=="S") or ($degree1[2]=="W"))
   {
   $decimal=$decimal*(-1);
   }
   $decimal=number_format($decimal,8,'.',''); //truncate decimal to 8 places
   return $decimal;
}
}
}



   function smssending()
    {  
    
    foreach ($this->cphone as $teleph)
    {

/* telephone format */

    if ($teleph[0] == '+')
    {
    $pmres = preg_match('|[+][0-9]{7,}+$|', $teleph, $matches); 
    $teleph=substr($teleph,1);
    }
    else
    $pmres  = preg_match('|[0-9]{7,}+$|', $teleph, $matches);
    if ($pmres==1 && !empty($matches))
    {
//vg 24.05.2020 asked to remove Google maps coordinates from SMS message and Email 
//next is as it was with Google Maps coordinates    
$urltosend = "Client:"." ".$this->cclient[0].", "."Message:"." ".$this->ctitle.", "."Attempt No.:"."$this->cattempt"." "."http://maps.google.com/maps?f=q&hl=en&q="."$this->x1".","."$this->y1"."&z=5";
//whithout Google Maps coordinates
//$urltosend = "Client:"." ".$this->cclient[0].", "."Message:"." ".$this->ctitle.", "."Attempt No.:"."$this->cattempt";
//." "."http://maps.google.com/maps?f=q&hl=en&q="."$this->x1".","."$this->y1"."&z=5";
     $urlencoded=urlencode($urltosend);
     $smsurl = 'https://sip1.xxxx.com/a2billing/customer/sendsms.php?';
     $myvars = "username=5555851&password=774402812&from=" . $this->msisdn . "&to=00" . $teleph ."&text=$urlencoded";
     $ch = curl_init( $smsurl );
     curl_setopt( $ch, CURLOPT_POST, 1);
     curl_setopt( $ch, CURLOPT_POSTFIELDS, $myvars);
     curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
     curl_setopt( $ch, CURLOPT_HEADER, 0);
     curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
     curl_setopt($ch,CURLOPT_TIMEOUT,60);
     $response = curl_exec( $ch );
    }
    }
    }



function getMail()
       {
       //var_dump($this->cemail);
       foreach ($this->cemail as $singlemail)
       {
       $mail = new PHPMailer();
       $mail->IsMail();
       $mail->From     = "support@xxxx.com";
       $mail->FromName = "Technology Ltd.";
       $mail->AddAddress($singlemail,'Customer');
       $mail->IsHTML(true);
       $mail->Subject = "MSIM email";
       //$mail->Body = "Test 1 of PHPMailer.";


$mail->Body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Untitled Document</title></head><body><div> Client:" . " ".$this->cclient[0].", "."Type:"." ".$this->ctitle.", "."Attempt No.:"."$this->cattempt"." "."http://maps.google.com/maps?f=q&hl=en&q=".$this->x1.",".$this->y1."&z=5</div>";
//       $mail->Body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Untitled Document</title></head><body><div> Client:" . " ".$this->cclient[0].", "."Type:"." ".$this->ctitle.", "."Attempt No.:"."$this->cattempt";






//$mail->Send();
if(!$mail->Send())
   {
   $mess = "Error sending: " . $mail->ErrorInfo;;
  // return $mess;
   }
else
   {
   $mess = "Letter sent";
 //  return $mess;
   }  

   }
   }




   function debug()
   {
   //var_dump($this->carr);
   var_dump($this->cphone);
   var_dump($this->cclient);
   var_dump($this->ctitle);
   var_dump($this->cattempt);
   var_dump($this->cemail);
   }

}


$DBHandle=DbConnect();

$xmldata      = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : file_get_contents("php://input");

//addition 09-02-21


if ( preg_match("/#CN;[0-9]+/", $xmldata) ) {
        $url = 'http://198.98.118.106/msim/msim.php?';
        //$url = 'http://5.29.147.108/msim/msim.php?';
        $ch = curl_init( $url );
        curl_setopt( $ch, CURLOPT_POST, 1);
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $xmldata);
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt( $ch, CURLOPT_HEADER, 0);
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch,CURLOPT_TIMEOUT,60);
        
        $response = curl_exec( $ch );
        
        //echo "\n";
        //print_r($response);
        //echo "\n";
	exit($response);
        
 } 

//end addition





if(!empty($xmldata))
  {
   $SimpleXML = new SimpleXMLElement($xmldata);
   $simpxmlarr = ((array)$SimpleXML);

//if ((!empty($simpxmlarr)) && (($_SERVER['REMOTE_ADDR'] == '213.57.246.55') || ($_SERVER['REMOTE_ADDR'] == '206.190.228.182') || ($_SERVER['REMOTE_ADDR'] == '204.154.244.162') || ($_SERVER['REMOTE_ADDR'] == '198.98.118.106')))
if ((!empty($simpxmlarr)) && (($_SERVER['REMOTE_ADDR'] == '213.57.246.55') || ($_SERVER['REMOTE_ADDR'] == '206.190.228.182') || ($_SERVER['REMOTE_ADDR'] == '204.154.244.162') || ($_SERVER['REMOTE_ADDR'] == '198.98.118.106') || ($_SERVER['REMOTE_ADDR'] == '174.127.112.116')))
{
        $msisdn   = $simpxmlarr['msisdn']; //var_dump($msisdn);
        $userdata = $simpxmlarr['user-data']; //var_dump($userdata);
        $imsi    = $simpxmlarr['imsi']; //var_dump($imsi);
//        $time     = gmdate("Y-m-d H:i:s");
        $time     = date("Y-m-d H:i:s");

$sql = "INSERT INTO `ussd_temp`
                SET `msisdn`    = '{$msisdn}',
                                `userdata`      = '{$userdata}',
                                `imsi`          = '{$imsi}',
                                `timestamp`     = '{$time}'
                                ";
        $DBHandle->Execute($sql);





   $xmlinst1st = new USSDXMLSMS();
   $xmlinst1st->split=$userdata; 
   $xmlinst1st->msisdn = $msisdn;
   $xmlinst1st->init();
  // var_dump($xmlinst1st->notel);
//commant made for the ECI (Electric company Israel)
   //if (($xmlinst1st->notitle) || ($xmlinst1st->notel)) 
   if (($xmlinst1st->notitle)) 
   {
   echo '<mo-submit-rvcl-response><user-data>Invalid argument supplied</user-data></mo-submit-rvcl-response>';
  // echo '<mo-submit-rvcl-response><user-data>Invalid argument supplied no message</user-data></mo-submit-rvcl-response>';
   exit();
   }


$xmlinst1st->smssending();
//var_dump($fg);   
$xmlinst1st->getMail();

echo '<mo-submit-rvcl-response><user-data>successx</user-data></mo-submit-rvcl-response>';
//echo '<mo-submit-rvcl-response><user-data>successx alert is sent</user-data></mo-submit-rvcl-response>';
}
else 
   {
    echo '<mo-submit-rvcl-response><user-data>Invalid argument supplied</user-data></mo-submit-rvcl-response>';
 //   echo '<mo-submit-rvcl-response><user-data>Invalid argument supplied IP not correct</user-data></mo-submit-rvcl-response>';
   } 
 }
else
    echo '<mo-submit-rvcl-response><user-data>Invalid argument supplied</user-data></mo-submit-rvcl-response>';
//    echo '<mo-submit-rvcl-response><user-data>Invalid argument supplied no data sent</user-data></mo-submit-rvcl-response>';

?>
