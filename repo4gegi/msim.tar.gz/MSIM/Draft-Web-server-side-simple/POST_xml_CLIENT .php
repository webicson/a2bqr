<?php

$myvars = '<mo-ussd-submit-request version="1.0" id="791"><msisdn>19406044449</msisdn><user-data>CL;Elbit#MSG;Manual#PN;+972543#ATN;0#EM;wgaitner@gmail.com</user-data><imsi>310630803000341</imsi></mo-ussd-submit-request>';

$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $myvars);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch,CURLOPT_TIMEOUT,60);
$response = curl_exec( $ch );
var_dump($response);
//return($response);
//print $response;
?>
